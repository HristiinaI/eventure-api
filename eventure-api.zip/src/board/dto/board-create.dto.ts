export class BoardCreateDto {
    name: string;
    eventId: string;
    lists: string[];
}
  
export const APP_CONFIG = {
    accessTokenExpires: '30s',
    refreshTokenExpires: '1m',
    jwtSecret: 'secretKey',
    jwtSession: {
        session: false,
    },
};

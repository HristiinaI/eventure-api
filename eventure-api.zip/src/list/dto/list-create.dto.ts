export class ListCreateDto {
    listTitle: string;
    boardId: string;
    cards: string[];
}
  
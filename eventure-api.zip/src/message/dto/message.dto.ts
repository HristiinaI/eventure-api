export class MessageDto {
    chatId: string;
    sender: string;
    isUser: boolean;
    message: string;
}
